//
//  Favorites.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/6/25.
//

import SwiftUI

final class Favorites: ObservableObject {
    
    @Published var items: [Recipe] = []
    
    func add(_ recipe: Recipe) {
        if !items.contains(where: { $0.id == recipe.id }) {
            items.append(recipe)
        }
        
    }
    
    func deleteItems(at offsets: IndexSet) {
        items.remove(atOffsets: offsets)
    }
    
    func remove(_ recipe: Recipe) {
        items.removeAll { $0.id == recipe.id}
    }
    
    func contains(_ recipe: Recipe) -> Bool {
        items.contains(where: {$0.id == recipe.id})
    }
    
    func toggle(_ recipe: Recipe) {
        if contains(recipe) {
            remove(recipe)
        } else {
            add(recipe)
        }
    }
    
}
