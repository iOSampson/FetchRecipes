//
//  Recipe.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/6/25.
//

import Foundation

struct Recipe: Decodable, Identifiable, Equatable {
    let id: String
    let name: String
    let cuisine: String
    let photoUrlLarge: String? // decoder.keyDecodingStrategy = .convertFromSnakeCase
    let photoUrlSmall: String?
    let sourceUrl: String?
    let youtubeUrl: String?
    
    
    enum CodingKeys: String, CodingKey {
        case id = "uuid"
        case name
        case cuisine
        case photoUrlLarge = "photo_url_large"
        case photoUrlSmall = "photo_url_small"
        case sourceUrl = "source_url"
        case youtubeUrl = "youtube_url"
    }
}


struct RecipeResponse: Decodable {
    let recipes: [Recipe]
}


struct MockData {
    
    static let sampleRecipe = Recipe(id: "0c6ca6e7-e32a-4053-b824-1dbf749910d8",
                                     name: "Apam Balik",
                                     cuisine: "Malaysian",
                                     photoUrlLarge: "https://d3jbb8n5wk0qxi.cloudfront.net/photos/b9ab0071-b281-4bee-b361-ec340d405320/large.jpg",
                                     photoUrlSmall: "https://d3jbb8n5wk0qxi.cloudfront.net/photos/b9ab0071-b281-4bee-b361-ec340d405320/small.jpg",
                                     sourceUrl: "https://www.nyonyacooking.com/recipes/apam-balik~SJ5WuvsDf9WQ",
                                     youtubeUrl: "https://www.youtube.com/watch?v=6R8ffRRJcrg")
    
    static let sampleRecipe2 = Recipe(id: "599344f4-3c5c-4cca-b914-2210e3b3312f",
                                     name: "Apple & Blackberry Crumble",
                                     cuisine: "British",
                                     photoUrlLarge: "https://d3jbb8n5wk0qxi.cloudfront.net/photos/535dfe4e-5d61-4db6-ba8f-7a27b1214f5d/large.jpg",
                                     photoUrlSmall: "https://d3jbb8n5wk0qxi.cloudfront.net/photos/535dfe4e-5d61-4db6-ba8f-7a27b1214f5d/small.jpg",
                                     sourceUrl: "https://www.bbcgoodfood.com/recipes/778642/apple-and-blackberry-crumble",
                                     youtubeUrl: "https://www.youtube.com/watch?v=4vhcOwVBDO4")
    
    static let sampleRecipe3 = Recipe(id: "74f6d4eb-da50-4901-94d1-deae2d8af1d1",
                                      name: "Apple Frangipan Tart",
                                      cuisine: "British",
                                      photoUrlLarge: "https://d3jbb8n5wk0qxi.cloudfront.net/photos/7276e9f9-02a2-47a0-8d70-d91bdb149e9e/large.jpg",
                                      photoUrlSmall: "https://d3jbb8n5wk0qxi.cloudfront.net/photos/7276e9f9-02a2-47a0-8d70-d91bdb149e9e/small.jpg",
                                      sourceUrl: nil,
                                      youtubeUrl: "https://www.youtube.com/watch?v=rp8Slv4INLk")

    
    static let recipes = [sampleRecipe, sampleRecipe2, sampleRecipe3, sampleRecipe]
}

