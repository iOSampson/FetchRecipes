//
//  FetchRecipesApp.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/6/25.
//

import SwiftUI

@main
struct FetchRecipesApp: App {
    
    var favorites = Favorites()
    
    var body: some Scene {
        WindowGroup {
            RecipeTabView().environmentObject(favorites)
        }
    }
}
