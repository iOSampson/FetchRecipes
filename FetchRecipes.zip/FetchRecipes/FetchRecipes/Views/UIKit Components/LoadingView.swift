//
//  LoadingView.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/9/25.
//

import SwiftUI

struct ActivityIndicator: UIViewRepresentable {
    
    func makeUIView(context: Context) -> UIActivityIndicatorView {
        let activityIndicatorView = UIActivityIndicatorView(style: .large)
        activityIndicatorView.color = UIColor.fetchPrimary
        activityIndicatorView.startAnimating()
        return activityIndicatorView
    }
    
    func updateUIView(_ uiView: UIActivityIndicatorView, context: Context) {}
    
}

struct LoadingView: View {
    var body: some View {
        ZStack {
            Color(.systemBackground)
                .ignoresSafeArea(edges: .all)
            
            ProgressView("Loading...")
                .progressViewStyle(CircularProgressViewStyle())
                .tint(.fetchPrimary)
                .scaleEffect(1.5)
        }
    }
}

#Preview {
    LoadingView()
}
