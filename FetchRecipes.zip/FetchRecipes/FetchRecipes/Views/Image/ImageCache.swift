//
//  ImageCache.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/17/25.
//

import SwiftUI

class ImageCache {
    static private var cache: [URL: Image] = [:]
    
    static subscript(url: URL) -> Image? {
        get {
            cache[url]
        }
        
        set {
            cache[url] = newValue
        }
    }
    
    static func clear() {
        cache.removeAll()
    }
}
