//
//  RecipeListCell.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/6/25.
//

import SwiftUI

struct RecipeListCell: View {
    
    let recipe: Recipe
    
    var body: some View {
        HStack {
            if let urlString = recipe.photoUrlSmall, let url = URL(string: urlString) {
                CachedAsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                        
                    case .failure:
                        Image(systemName: "xmark.octagon")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .foregroundStyle(.fetchPrimary)
                        
                    case .empty:
                        ProgressView()
                        
                    @unknown default:
                        Image(systemName: "questionmark")
                    }
                }
                .frame(width: 100, height: 100)
                .clipShape(RoundedRectangle(cornerRadius: 8))
            } else {
                Image(systemName: "exclamationmark.triangle")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .foregroundStyle(.fetchSecondary)
            }
            
            VStack(alignment: .leading, spacing: 5) {
                Text(recipe.name)
                    .foregroundStyle(.fetchSecondary)
                    .font(.title2)
                    .fontWeight(.medium)
                
                Text(recipe.cuisine)
                    .foregroundStyle(.fetchPrimary)
                    .fontWeight(.semibold)
            }
            .padding(.leading)
        }
    }
}
