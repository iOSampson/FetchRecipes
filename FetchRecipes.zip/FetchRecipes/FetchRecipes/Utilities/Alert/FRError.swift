//
//  FRError.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/6/25.
//

import Foundation

enum FRError: Error {
    case invalidURL
    case invalidResponse
    case invalidData
    case unableToComplete
}
