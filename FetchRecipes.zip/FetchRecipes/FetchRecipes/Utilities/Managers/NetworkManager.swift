//
//  NetworkManager.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/6/25.
//

import Foundation

final class NetworkManager {
    
    static let shared = NetworkManager()
    
    static let baseURL = "https://d3jbb8n5wk0qxi.cloudfront.net/"
    private let recipeURL = baseURL + "recipes.json"
    private let malformedRecipeURL = baseURL + "recipes-malformed.json"
    private let emptyDataRecipeURL = baseURL + "recipes-empty.json"
    
    
    private init() {}
    
    func getRecipes() async throws -> [Recipe] {
        
        // The URL that we have works
        guard let url = URL(string: recipeURL) else {
            throw FRError.invalidURL
        }
        
        // Wifi or Connection isn't working
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
            throw FRError.invalidResponse
        }
        
        //print(String(data: data, encoding: .utf8) ?? "Unable to convert data to string")
        
        do {
            let decoder = JSONDecoder()
            //decoder.keyDecodingStrategy = .convertFromSnakeCase
            return try decoder.decode(RecipeResponse.self, from: data).recipes
            
        } catch {
            throw FRError.invalidData
        }
        
        
    }
    
}
//    func getRecipes(completed: @escaping (Result<[Recipe], FRError>) -> Void) {
//        
//        // The URL that we have works
//        guard let url = URL(string: baseURL) else {
//            completed(.failure(.invalidURL))
//            return
//        }
//        
//        // Wifi or Connection isn't working
//        let task = URLSession.shared.dataTask(with: URLRequest(url: url)) { data, response, error in
//            if let error = error {
//                completed(.failure(.unableToComplete))
//                return
//            }
//            
//            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
//                completed(.failure(.invalidResponse))
//                return
//            }
//            
//            guard let data = data else {
//                completed(.failure(.invalidData))
//                return
//            }
//            
//            do {
//                let decoder = JSONDecoder()
//                decoder.keyDecodingStrategy = .convertFromSnakeCase
//                let decodedResponse = try decoder.decode(RecipeResponse.self, from: data)
//                completed(.success(decodedResponse.recipes))
//            } catch {
//                completed(.failure(.invalidData))
//            }
//        }
//        
//        task.resume()
//    }
