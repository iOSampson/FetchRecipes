//
//  RecipeTabView.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/6/25.
//

import SwiftUI

struct RecipeTabView: View {
    
    @EnvironmentObject var favorites: Favorites
    
    var body: some View {
        TabView {
            RecipeListView()
                .tabItem { Label("Recipes", systemImage: "fork.knife") }
            
            FavoritesListView()
                .tabItem { Label("Favorites", systemImage: "star") }
        }
        .tint(.fetchPrimary)
    }
}

#Preview {
    RecipeTabView()
}
