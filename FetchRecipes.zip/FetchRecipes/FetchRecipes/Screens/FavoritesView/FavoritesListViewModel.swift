//
//  FavoritesListViewModel.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/12/25.
//

import SwiftUI

@MainActor final class FavoritesListViewModel: ObservableObject {
    
    @Published var isShowingDetail = false
    @Published var selectedRecipe: Recipe?
    
    
}

