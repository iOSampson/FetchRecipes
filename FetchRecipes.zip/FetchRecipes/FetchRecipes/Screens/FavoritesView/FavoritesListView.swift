//
//  FavoritesView.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/7/25.
//

import SwiftUI

struct FavoritesListView: View {
    
    @EnvironmentObject var favorites: Favorites
    @StateObject var viewModel = FavoritesListViewModel()
    
    var body: some View {
        ZStack {
            NavigationView {
                List {
                    ForEach(favorites.items) { recipe in
                        RecipeListCell(recipe: recipe)
                            .onTapGesture {
                                viewModel.selectedRecipe = recipe
                                viewModel.isShowingDetail = true
                            }
                        
                    }
                    .onDelete(perform: favorites.deleteItems)
                    .listStyle(.plain)
                }
                .disabled(viewModel.isShowingDetail)
                .navigationTitle("⭐️ Favorites")
            }
            .background(viewModel.isShowingDetail ? .fetchSecondary : .fetchPrimary)
            .blur(radius: viewModel.isShowingDetail ? 20 : 0)
            
            if viewModel.isShowingDetail {
                RecipeDetailView(recipe: viewModel.selectedRecipe!, isShowingDetail: $viewModel.isShowingDetail)
            }
            
            if favorites.items.isEmpty {
                EmptyState(imageName: "star.slash", message: "No favorites yet!\nYour starred recipes will show up here. See something delicious? Just tap the star to save it.")
            }
            
        }
    }
}
    
#Preview {
    FavoritesListView()
}
    

