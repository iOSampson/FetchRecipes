//
//  RecipeDetailView.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/7/25.
//

import SwiftUI

struct RecipeDetailView: View {
    
    @EnvironmentObject var favorites: Favorites
    
    let recipe: Recipe

    @Binding var isShowingDetail: Bool
    @State private var isShowingSafariView = false
    @State private var webPage: String = ""
    
    var body: some View {
        VStack {
            // image
            if let urlString = recipe.photoUrlLarge, let url = URL(string: urlString) {
                CachedAsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                        
                    case .failure:
                        Image(systemName: "xmark.octagon")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .foregroundStyle(.fetchPrimary)
                        
                    case .empty:
                        ProgressView()
                        
                    @unknown default:
                        Image(systemName: "questionmark")
                    }
                }
                .frame(width: 300, height: 225)
            } else {
                Image(systemName: "exclamationmark.triangle")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 300, height: 225)
                    .foregroundStyle(.fetchSecondary)
            }
            
            
            Spacer()
            // text information
            VStack {
                Text(recipe.name)
                    .font(.title2)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.center)
                
                Text(recipe.cuisine)
                    .font(.body)
                
                HStack(spacing: 20) {
                    
                    if recipe.youtubeUrl != nil {
                        Button {
                            isShowingSafariView = true
                            webPage = "video"
                        } label: {
                            //APButton(title: "$\(appetizer.price, specifier: "%.2f") - Add to Order")
                            Text("Video")
                        }
                        .buttonStyle(.bordered)
                        .tint(.fetchPrimary)
                        .controlSize(.large)
                    }
                    
                    
                    if recipe.sourceUrl != nil {
                        Button {
                            isShowingSafariView = true
                            webPage = "web"
                        } label: {
                            //APButton(title: "$\(appetizer.price, specifier: "%.2f") - Add to Order")
                            Text(" Web ")
                        }
                        .buttonStyle(.bordered)
                        .tint(.fetchSecondary)
                        .controlSize(.large)
                    }
                    
                    
                    
                    Button {
                        favorites.toggle(recipe)
                    } label: {
                        Image(systemName: favorites.contains(recipe) ? "star.fill" : "star")
                            .foregroundColor(favorites.contains(recipe) ? .fetchPrimary : .fetchSecondary)
                                        .font(.title2)
                    }
                }
                
            }
            .fullScreenCover(isPresented: $isShowingSafariView) {
                if webPage == "video" {
                    SafariView(url: URL(string: recipe.youtubeUrl ?? "www.fetch.com")!)
                } else if webPage == "web" {
                    SafariView(url: URL(string: recipe.sourceUrl ?? "www.fetch.com")!)
                }
                
            }
            
            Spacer()
        }
        .frame(width: 300, height: 525)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(radius: 40)
        .overlay(Button {
            isShowingDetail = false
        } label: {
            XDismissButton()
        }, alignment: .topTrailing)
    }
}

#Preview {
    RecipeDetailView(recipe: MockData.sampleRecipe, isShowingDetail: .constant(true))
}
