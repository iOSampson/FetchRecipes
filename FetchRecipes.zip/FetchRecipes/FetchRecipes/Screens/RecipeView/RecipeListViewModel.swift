//
//  RecipeListViewModel.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/6/25.
//

import SwiftUI

@MainActor final class RecipeListViewModel: ObservableObject {
    
    @Published var recipes: [Recipe] = []
    @Published var alertItem: AlertItem?
    @Published var isLoading = false
    @Published var isShowingDetail = false
    @Published var selectedRecipe: Recipe?
    
    func getRecipes() {
        
        isLoading = true
        
        Task {
            do {
                recipes = try await NetworkManager.shared.getRecipes()
                isLoading = false
                
            } catch {
                if let frError = error as? FRError {
                    switch frError {
                        
                    case .invalidURL:
                        alertItem = AlertContext.invalidURL
                        
                    case .invalidResponse:
                        alertItem = AlertContext.invalidResponse
                        
                    case .invalidData:
                        alertItem = AlertContext.invalidData
                        
                    default:
                        alertItem = AlertContext.invalidResponse
                    }
                } else {
                    alertItem = AlertContext.invalidResponse // generic error
                }
                
                isLoading = false
            }
        }
    }
}
