//
//  RecipeListView.swift
//  FetchRecipes
//
//  Created by Sampson Ezieme on 6/6/25.
//

import SwiftUI

struct RecipeListView: View {
    
    @StateObject var viewModel = RecipeListViewModel()
    
    var body: some View {
        ZStack {
            NavigationView {
                List(viewModel.recipes) { recipe in
                    RecipeListCell(recipe: recipe)
                        .onTapGesture {
                            viewModel.selectedRecipe = recipe
                            viewModel.isShowingDetail = true
                        }
                }
                .navigationTitle("🍴 Recipes")
                .listStyle(.plain)
                .disabled(viewModel.isShowingDetail)
            }
            .task {
                viewModel.getRecipes()
            }
            .background(viewModel.isShowingDetail ? .fetchPrimary : .fetchSecondary)
            .blur(radius: viewModel.isShowingDetail ? 20 : 0)
                        
            if viewModel.isShowingDetail {
                RecipeDetailView(recipe: viewModel.selectedRecipe!, isShowingDetail: $viewModel.isShowingDetail)
            }
            
            if viewModel.isLoading {
                LoadingView()
            }
            
            if viewModel.recipes.isEmpty {
                EmptyState(imageName: "fork.knife.circle", message: "No recipes found — yet!\nLooks like there’s nothing to show right now. Check back later.")
            }
        }
        .alert(item: $viewModel.alertItem) { alertItem in
            Alert(title: alertItem.title, message: alertItem.message, dismissButton: alertItem.dismissButton)
        }
        
       
        
    }
}

#Preview {
    RecipeListView()
}
