//
//  CachedAsyncImageTests.swift
//  FetchRecipesTests
//
//  Created by Sampson Ezieme on 6/17/25.
//

import XCTest
import SwiftUI
@testable import FetchRecipes

final class CachedAsyncImageTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        ImageCache.clear()
    }
    
    
    override func tearDown() {
        ImageCache.clear()
        super.tearDown()
    }

    
    func testImageIsStoredInCache() {
        let url = URL(string: "https://test.com/test.png")!
        let cacheImage = Image(systemName: "person")
        
        ImageCache[url] = cacheImage
        
        let _ = CachedAsyncImage(url: url) { phase in
            if case .success(_) = phase {
                XCTAssertNotNil(ImageCache[url])
            }
            
            return Text("Loaded")
        }
        
        XCTAssertNotNil(ImageCache[url])
        
    }
    
    
    func testImageIsNotStoredOnFailure() {
        let url = URL(string: "https://test.com/fail.png")!
        
        let _ = CachedAsyncImage(url: url) { phase in
            if case .failure(_) = phase {
                // Nothing
            }
            
            return Text("Failed Case")
        }
        
        XCTAssertNil(ImageCache[url])
    }
    
    
    func testImageIsNotStoredOnEmpty() {
        let url = URL(string: "https://test.com/empty.png")!
        
        let _ = CachedAsyncImage(url: url) { phase in
            if case .empty = phase {
                // Nothing
            }
            
            return Text("Empty")
        }
        
        XCTAssertNil(ImageCache[url])
    }
    

}
