//
//  FavoritesTests.swift
//  FetchRecipesTests
//
//  Created by Sampson Ezieme on 6/18/25.
//

import XCTest
@testable import FetchRecipes

final class FavoritesTests: XCTestCase {

    func testAddToFavorites() {
        // Arrange
        let favorite = Favorites()
        
        // Act
        XCTAssertEqual(favorite.items, [])
        
        favorite.add(MockData.sampleRecipe)
        
        // Assert
        XCTAssertEqual(favorite.items, [MockData.sampleRecipe])
    }
    
    
    func testDeleteItemsFromFavorites() {
        // Arrange
        let favorite = Favorites()
        
        // Act
        XCTAssertEqual(favorite.items, [])
        favorite.add(MockData.sampleRecipe)
        XCTAssertEqual(favorite.items.count, 1)
        
        favorite.deleteItems(at: IndexSet(integer: 0))
        
        // Assert
        XCTAssertEqual(favorite.items.count, 0)
    }
    
    
    func testRemoveFromFavorites() {
        // Arrange
        let favorite = Favorites()
        
        // Act
        XCTAssertEqual(favorite.items, [])
        favorite.add(MockData.sampleRecipe)
        favorite.add(MockData.sampleRecipe2)
        favorite.add(MockData.sampleRecipe3)
        XCTAssertEqual(favorite.items.count, 3)
        
        favorite.remove(MockData.sampleRecipe2)
        
        // Assert
        XCTAssertEqual(favorite.items, [MockData.sampleRecipe, MockData.sampleRecipe3])
        
    }
    
    
    func testContainsInFavorites() {
        // Arrange
        let favorite = Favorites()
        
        // Act
        XCTAssertEqual(favorite.items, [])
        favorite.add(MockData.sampleRecipe)
        favorite.add(MockData.sampleRecipe2)
        favorite.add(MockData.sampleRecipe3)
        XCTAssertEqual(favorite.items.count, 3)
        
        // Assert
        let result = favorite.contains(MockData.sampleRecipe2)
        XCTAssertTrue(result)
        
        favorite.remove(MockData.sampleRecipe3)
        let result2 = favorite.contains(MockData.sampleRecipe3)
        XCTAssertFalse(result2)
        
    }
    
    
    func testToggleFromFavorites() {
        // Arrange
        let favorite = Favorites()
        
        // Act
        XCTAssertEqual(favorite.items, [])
        
        favorite.toggle(MockData.sampleRecipe)
        
        // Assert
        XCTAssertEqual(favorite.items, [MockData.sampleRecipe])
        
        // Act ii
        favorite.toggle(MockData.sampleRecipe)
        
        // Assert ii
        XCTAssertEqual(favorite.items, [])
    }

}
